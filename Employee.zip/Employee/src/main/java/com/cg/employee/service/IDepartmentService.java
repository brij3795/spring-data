package com.cg.employee.service;

import com.cg.employee.entities.Department;

public interface IDepartmentService {

	public Department addDepartment(Department department);

	// public	Department addDepartment(Department department, int empId);

}
